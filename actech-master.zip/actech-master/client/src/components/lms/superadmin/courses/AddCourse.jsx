import React from 'react'

export default function AddCourse() {
    return (
        <div>
            
        </div>
    )
}
