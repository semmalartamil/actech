import React from 'react';
import './ViewCourse.scss';

export default function ViewCourse() {
    return (
        <div>
            <h1>View course</h1>
        </div>
    )
}
