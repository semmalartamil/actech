import React from 'react';
import SuperAdminLogin from '../../form/SuperAdminLogin';
export default function Login() {
    return (
        <div>
            <SuperAdminLogin />
        </div>
    )
}
