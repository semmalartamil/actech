import React from 'react';
import './True.scss';

const Write = () => {
    return (
        <div className='writing'>
        <div className="txtbox1">
            <div className="questions">Writing</div>
            <div className="txt_box">
                <textarea className="text_box" id="story" name="story"
                    rows="5" cols="33">

                </textarea>
            </div>
        </div>

        
                

                            </div>
                       
        
    );
}

export default Write;
