import React from 'react'
import AddMenteeComponent from '../../components/lms/superadmin/usermanager/AddMentee.component'
import AdminLayout from '../../components/layout/AdminLayout';

const AddMentee = ({ classes, children }) => {
    return (
        <div>
            <AddMenteeComponent />
        </div>
    )
}
export default AddMentee;