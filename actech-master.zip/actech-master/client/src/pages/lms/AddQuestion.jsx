import React from 'react';
import AdminLayout from '../../components/layout/AdminLayout';
import AddQuestion from '../../components/lms/superadmin/courses/Addquestion';

export default function Addquestion() {
    return (
        <AdminLayout>
            <AddQuestion/>
        </AdminLayout>
    )
}