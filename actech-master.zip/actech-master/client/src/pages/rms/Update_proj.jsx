import React from 'react'
import Adminlayout from '../../components/layout/Adminlayout_rms'
import Update_project from '../../components/rms/Project_profile/Update_project';

function Update_proj() {
    return (
        <div>
             <Adminlayout>
                <Update_project />
            </Adminlayout>
        </div>
    )
}

export default Update_proj
